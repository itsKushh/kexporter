# kexporter

> 🧾 Exportateur de salons ou fils Discord au format HTML, avec rendu fidèle à l'interface Discord.  
> 🧾 Export Discord channels or threads to HTML, with a layout close to Discord's UI.

![PyPI - Version](https://img.shields.io/pypi/v/kexporter?style=flat-square)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/kexporter?style=flat-square)
![License](https://img.shields.io/badge/license-MIT%20with%20Attribution-blue?style=flat-square)

---

## 🇫🇷 À propos

`kexporter` est un module Python qui permet d’exporter des messages de salons ou de fils Discord vers un fichier HTML statique, visuellement proche de l’interface réelle de Discord.

Il est utile pour :
- archiver des conversations importantes ;
- créer des rapports client / ticket ;
- documenter des échanges dans un format lisible hors ligne.

---

## 🇬🇧 About

`kexporter` is a Python module that exports messages from Discord channels or threads into a static HTML file, visually similar to Discord's native interface.

Useful for:
- archiving important discussions;
- generating client or ticket transcripts;
- creating offline-readable message logs.

---

## 📦 Installation

**PyPI:**

```bash
pip install kexporter
```

**TestPyPI:**

```bash
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple kexporter
```

---

## ⚙️ Utilisation / Usage

```python
from kexporter import export

# Exemple fictif / Example usage
await export(channel, output_path="transcript.html")
```

⚠️ Ton bot Discord doit avoir la permission de lire l'historique.  
⚠️ Your bot must have permission to read message history.

---

## ✅ Fonctionnalités / Features

- ✅ Export HTML statique / Static HTML export
- 🖼️ Avatars et pseudos / Avatars and usernames
- 🕒 Horodatage des messages / Timestamped messages
- 🎨 Rendu fidèle à Discord / Discord-like layout
- 📎 Pièces jointes supportées (optionnel) / Attachment support (optional)
- 🔧 Facilement intégrable / Easy to integrate

---

## 🖼️ Aperçu / Preview

*(Ajoutez une capture ici / Add a screenshot here)*  
`transcript.html`

---

## 🔧 Dépendances / Dependencies

- `discord.py >= 2.0`
- `jinja2 >= 3.0`

---

## 📄 Licence / License

**MIT avec clause d’attribution / MIT with attribution clause**

> Ce logiciel est open-source, mais toute redistribution ou modification **doit mentionner l’auteur original** dans le code source et/ou l’interface générée.  
> This software is open-source, but any redistribution or modification **must credit the original author** in the source code and/or generated output.

---

## 🙋‍♂️ Auteur / Author

Développé par [Kushh](https://github.com/itsKushh)  
Developed by [Kushh](https://github.com/itsKushh)

Contact : [its.kushh.dev@gmail.com](mailto:its.kushh.dev@gmail.com)

---

## 💡 Contribuer / Contributing

Les pull requests sont bienvenues ! Forkez le projet et proposez vos idées.  
Pull requests are welcome! Fork the project and share your ideas.
